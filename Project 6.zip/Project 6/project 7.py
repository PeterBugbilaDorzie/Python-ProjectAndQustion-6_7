# Project 7: Logging Decorator with Factory Function

def make_logger(prefix):
    """
    Factory function that returns a decorator with a custom prefix.
    """
    def logger_decorator(func):
        def wrapper(*args, **kwargs):
            print(f"{prefix} Entering {func.__name__}")
            result = func(*args, **kwargs)
            print(f"{prefix} Exiting {func.__name__}")
            return result
        return wrapper
    return logger_decorator


# Example usage
@make_logger("[MathModule]")
def add(a, b):
    return a + b

@make_logger("[NetworkModule]")
def connect_server():
    print("Connecting to server...")


# Test the functions
add(3, 5)
connect_server()