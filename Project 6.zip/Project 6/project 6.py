# Project 6: Flower Class

class Flower:
    def __init__(self):
        self.price = 0.0
        self.color = ""
        self.smell = ""

    def get(self):
        """Input method to set flower properties"""
        self.color = input("Enter the color of the flower: ")
        self.price = float(input("Enter the price of the flower: "))
        self.smell = input("Enter the smell of the flower (e.g., sweet, mild): ")

    def display(self):
        """Display method to show flower details"""
        print(f"Flower Details:")
        print(f"  Color: {self.color}")
        print(f"  Price: ${self.price:.2f}")
        print(f"  Smell: {self.smell}")
        print("-" * 30)


# Creating objects (instances) of Flower class
lilly = Flower()
rose = Flower()
hibiscus = Flower()

# Input and display for each flower
print("Enter details for Lilly:")
lilly.get()

print("Enter details for Rose:")
rose.get()

print("Enter details for Hibiscus:")
hibiscus.get()

# Display all flower details
lilly.display()
rose.display()
hibiscus.display()